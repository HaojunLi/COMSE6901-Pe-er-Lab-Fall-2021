## Lecture 6 - Phylogenetic signal and phylogenetic diversity

Phylogenetic signal (Moran's I, Abouheif's c, Pagel's lambda, Blomberg's K, Moran's I correlograms); Phylogenetic diversity; Evolutionary distinctiveness; phylogenetic beta-diversity; Parametric bootstrapping; Phylogenies in community ecology.

### Tutorial

[Phylogenetic signal and PD](http://htmlpreview.github.com/?http://github.com/simjoly/CourseComparativeMethods/blob/master/lecture6/PD.html)
