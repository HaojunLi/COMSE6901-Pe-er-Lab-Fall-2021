# Lecture 3 - Ancestral states reconstruction

Reconstruction of ancestral states on phylogenies for quantitative and qualitative (discrete) characters; marginal vs joint estimation; model selection; stochastic character mapping.

[Ancestral states reconstruction](http://htmlpreview.github.com/?http://github.com/simjoly/CourseComparativeMethods/blob/master/lecture3/AncestralStatesReconstruction.html)
