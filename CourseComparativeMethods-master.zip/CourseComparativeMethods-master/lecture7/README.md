## Lecture 7 - Diversification analyses

Diversification rate estimation; Birth-death and Yule models; Lineage through-time (ltt) plots; Trait dependent speciaton and extinction (BISSE model).

### Tutorial

[Diversification](http://htmlpreview.github.com/?http://github.com/simjoly/CourseComparativeMethods/blob/master/lecture7/Diversification.html)
