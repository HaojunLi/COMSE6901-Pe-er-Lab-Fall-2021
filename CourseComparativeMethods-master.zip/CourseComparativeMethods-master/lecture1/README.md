# Introduction to phylogenies in R

There are two example in this course. The first one is an introduction to the RMarkdown langage, whereas the second is a intro to using phylogenies in R.

[RMardown example](http://htmlpreview.github.com/?http://github.com/simjoly/CourseComparativeMethods/blob/master/course1/First_RMarkdown_Document.html)

[Introduction to phylogenies in R](http://htmlpreview.github.com/?http://github.com/simjoly/CourseComparativeMethods/blob/master/course1/Introduction_phylo.html)
