# Lecture 2 - Phylogenetic Comparative Methods

The Brownian Motion (BM) model, Phylogenetic Independent Contrasts (PIC), Phylogenetic General Least Squares (PGLS), Phylogenetic Principal Component Analysis (pPCA).

[Phylogenetic Comparative Methods](http://htmlpreview.github.com/?http://github.com/simjoly/CourseComparativeMethods/blob/master/lecture2/StatsPhylo.html)

[Reading and making phylogenetic trees in R](http://htmlpreview.github.com/?http://github.com/simjoly/CourseComparativeMethods/blob/master/lecture2/PhylogeneticTree.html)
