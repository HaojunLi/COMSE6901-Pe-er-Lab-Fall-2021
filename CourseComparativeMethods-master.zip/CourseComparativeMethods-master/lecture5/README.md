# Lecture 5 - Other methods of trait evolution

Ornstein-Uhlenbeck (OU) model, Early-Burst model, Speciational model, Simulating data under different evolutionary models, OU models with multiple selection regimes, Accounting for phylogenetic uncertainty.

## Tutorial

[OUModels](http://htmlpreview.github.com/?http://github.com/simjoly/CourseComparativeMethods/blob/master/lecture5/OUModels.html)
